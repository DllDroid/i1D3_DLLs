The 3 files in the archive should be copied into the main ColourSpace installation directory

Single user (me only): C:\Users\xxxx\AppData\Local\Programs\Light Illusion\ColourSpace
All users: C:\Program Files (x86)\Light Illusion\ColourSpace

From this directory the install.bat should be executed as administrator
(Right click the .bat file and select 'Run As Administrator')

After any ColourSpace update or re-installation the above procedure will need to be re-run in full