The 3 files in the archive should be copied to the PC Desktop

The install.bat file should be executed as administrator, ignoring any Protection Warning messages
(Right click the .bat file and select 'Run As Administrator')

After any ColourSpace update or re-installation the above procedure will need to be re-run in full